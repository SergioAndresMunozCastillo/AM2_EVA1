package com.example.eva1_1_fragments;


import android.content.Context;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class RedFragment extends Fragment {
    public Context context;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        Log.wtf("Red", "onCreateView");
        return inflater.inflate(R.layout.fragment_red, container, false);
    }

    @Override
    public void onAttach(Context context) {

        super.onAttach(context);
        this.context = context;
        Log.wtf("Red", "onAttach");
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.wtf("Red", "onCreate");
    }

    @Override
    public void onStart() {
        super.onStart();
        Log.wtf("Red", "onStart");
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.wtf("Red", "onResume");
    }

    @Override
    public void onPause() {
        super.onPause();
        Log.wtf("Red", "onPause");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.wtf("Red", "onDestroy");
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        Log.wtf("Red", "onDestroyView");
    }

    @Override
    public void onDetach() {
        super.onDetach();
        Log.wtf("Red", "onDetach");
    }
}
