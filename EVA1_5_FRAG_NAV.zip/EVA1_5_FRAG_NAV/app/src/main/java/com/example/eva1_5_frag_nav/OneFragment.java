package com.example.eva1_5_frag_nav;


import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;


/**
 * A simple {@link Fragment} subclass.
 */
public class OneFragment extends Fragment {
        private View.OnClickListener miClickListener;

        public void setMiClickListener(View.OnClickListener miClickListener){
            this.miClickListener = miClickListener;
        }
    public OneFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        LinearLayout ly = (LinearLayout) inflater.inflate(R.layout.fragment_one, container, false);
        Button btn = ly.findViewById(R.id.button);
        btn.setOnClickListener(miClickListener);
        return ly;

    }

        public void exFragTwo(View view){

        }
}
