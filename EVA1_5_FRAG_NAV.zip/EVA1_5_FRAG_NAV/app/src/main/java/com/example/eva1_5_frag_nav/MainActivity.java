package com.example.eva1_5_frag_nav;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Procedimiento estándar para colocar un fragmento en android
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        OneFragment btnFragment = new OneFragment();

        btnFragment.setMiClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                FragmentTransaction ft2 = getSupportFragmentManager().beginTransaction();
                ft2.setCustomAnimations(R.anim.anim_enter, R.anim.anim_exit, R.anim.anim_enter, R.anim.anim_exit);
                TwoFragment blankFragment = new TwoFragment();
                ft2.replace(R.id.frmLyFragmentos, blankFragment);
                ft2.addToBackStack("HELLO FUHRER");
                ft2.commit();
            }
        });
        ft.replace(R.id.frmLyFragmentos, btnFragment);
        ft.addToBackStack("HELLO FUHRER");
        ft.commit();
    }
}
