package com.example.eva1_2_frag_com;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    ButtonFragment btnFragment;
    LifeFragment lfeFragment;
    TextView txtVwMensa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtVwMensa = findViewById(R.id.txtVwMensa);
    }

    @Override
    public void onAttachFragment(Fragment fragment) {
        super.onAttachFragment(fragment);
        if(fragment.getClass() == ButtonFragment.class){
            btnFragment = (ButtonFragment)fragment;
        }else if(fragment.getClass() == LifeFragment.class){
            lfeFragment = (LifeFragment)fragment;
        }
    }
                                        //Quien,        que
    public void onMessageFromFragToMain (String Sender, String param){
            if(Sender.equals("Lista")){
                txtVwMensa.setText("Lista " + param);
            }else if(Sender.equals("Boton")){
                txtVwMensa.setText("Boton " + param);
            }
    }
}