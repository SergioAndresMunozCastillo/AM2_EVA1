package com.example.eva1_4_frag_din_orienta;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.widget.FrameLayout;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Intent inSecun = new Intent();
    FrameLayout frmLyDetail;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onMessageFromFragToMain(){
        frmLyDetail = findViewById(R.id.frmLyDetail);
        if(frmLyDetail != null){
            //LANDSCAPE
            //CREAR EL GRAMENTO 2 DINAMICAMENTE
            Toast.makeText(this, "LANDSCAPE", Toast.LENGTH_SHORT);
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            TwoFragment two = new TwoFragment();
            two.setParam("ESTE ES EL MENSAJE!!!");
            ft.replace(R.id.frmLyDetail, two);
            ft.commit();
        }else{
            //PORTRAIT
            //LANZA LA ACTIVIDAD SECUNDARIA CON UN INTENTO
            Toast.makeText(this, "PORTRAIT", Toast.LENGTH_SHORT);
            inSecun = new Intent(this, Secundaria.class);
            inSecun.putExtra("MENSAJE", "ESTE ES EL MENSAJE");
            startActivity(inSecun);
        }
    }
}